#pragma once
#include "List.h"
#include "Mesh.h"
#include <memory>
#include <iostream>

class LIB_API Test {
public:
	Test();
	~Test();
	void testAll();
};

